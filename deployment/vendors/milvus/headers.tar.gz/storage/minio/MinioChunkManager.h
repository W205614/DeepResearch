// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <aws/core/Aws.h>
#include <aws/core/http/HttpClientFactory.h>
#include <aws/core/http/HttpRequest.h>
#include <aws/core/http/HttpTypes.h>
#include <aws/core/http/URI.h>
#include <aws/core/http/curl/CurlHttpClient.h>
#include <aws/core/http/standard/StandardHttpRequest.h>
#include <aws/core/utils/logging/FormattedLogSystem.h>
#include <aws/s3/S3Client.h>
#include <fmt/core.h>
#include <google/cloud/credentials.h>
#include <google/cloud/internal/oauth2_credentials.h>
#include <google/cloud/internal/oauth2_compute_engine_credentials.h>
#include <google/cloud/internal/oauth2_google_credentials.h>
#include <google/cloud/internal/oauth2_http_client_factory.h>
#include <google/cloud/internal/rest_client.h>
#include <google/cloud/storage/oauth2/compute_engine_credentials.h>
#include <google/cloud/storage/oauth2/google_credentials.h>
#include <google/cloud/status_or.h>
#include <stddef.h>
#include <stdint.h>
#include <atomic>
#include <memory>
#include <mutex>
#include <ostream>
#include <string>
#include <utility>
#include <vector>

#include "aws/core/client/ClientConfiguration.h"
#include "aws/core/http/HttpClient.h"
#include "aws/core/utils/logging/LogLevel.h"
#include "aws/core/utils/memory/stl/AWSAllocator.h"
#include "aws/core/utils/memory/stl/AWSStreamFwd.h"
#include "aws/core/utils/memory/stl/AWSString.h"
#include "aws/s3/S3Errors.h"
#include "common/EasyAssert.h"
#include "glog/logging.h"
#include "google/cloud/status.h"
#include "log/Log.h"
#include "storage/ChunkManager.h"
#include "storage/GcpStatus.h"
#include "storage/Types.h"
#include "storage/aliyun/AliyunCredentialsProvider.h"
#include "storage/huawei/HuaweiCloudCredentialsProvider.h"
#include "storage/tencent/TencentCloudCredentialsProvider.h"

namespace milvus::storage {

enum class RemoteStorageType {
    S3 = 0,
    GOOGLE_CLOUD = 1,
    ALIYUN_CLOUD = 2,
};

void
ConfigureGoogleCloudIAMHttpClientFactory(Aws::SDKOptions& sdk_options);

template <typename... Args>
static std::string
S3ErrorMessage(const std::string& func,
               const Aws::S3::S3Error& err,
               const std::string& fmt_string,
               Args&&... args) {
    std::ostringstream oss;
    const auto& message =
        fmt::format(fmt::runtime(fmt_string), std::forward<Args>(args)...);
    oss << "Error in " << func << "[errcode:" << int(err.GetResponseCode())
        << ", exception:" << err.GetExceptionName()
        << ", errmessage:" << err.GetMessage() << ", params:" << message << "]";
    return oss.str();
}

inline ErrorCode
S3ErrorToErrorCode(Aws::S3::S3Errors error,
                   Aws::Http::HttpResponseCode response_code,
                   bool should_retry) {
    switch (error) {
        case Aws::S3::S3Errors::NO_SUCH_BUCKET:
            return ErrorCode::BucketInvalid;
        case Aws::S3::S3Errors::NO_SUCH_KEY:
        case Aws::S3::S3Errors::RESOURCE_NOT_FOUND:
            return ErrorCode::ObjectNotExist;
        case Aws::S3::S3Errors::UNKNOWN:
            // S3-compatible services may return a non-standard error name the
            // SDK cannot map, so its retry flag is unreliable here; fall back
            // to the structured HTTP status for the retry decision.
            return Aws::Http::IsRetryableHttpResponseCode(response_code)
                       ? ErrorCode::S3Error
                       : ErrorCode::UnexpectedError;
        default:
            // Defer the transient-vs-permanent decision to the AWS SDK's own
            // retryability classification (throttling, 5xx, timeouts,
            // REQUEST_EXPIRED, REQUEST_TIME_TOO_SKEWED, network, and any future
            // error type), instead of a hand-maintained list that drifts from
            // it. NoSuchBucket / NoSuchKey above stay permanent by identity.
            return should_retry ? ErrorCode::S3Error
                                : ErrorCode::UnexpectedError;
    }
}

template <typename... Args>
static SegcoreError
ThrowS3Error(const std::string& func,
             const Aws::S3::S3Error& err,
             const std::string& fmt_string,
             Args&&... args) {
    std::string error_message = S3ErrorMessage(func, err, fmt_string, args...);
    LOG_WARN("{}", error_message);
    throw SegcoreError(
        S3ErrorToErrorCode(
            err.GetErrorType(), err.GetResponseCode(), err.ShouldRetry()),
        error_message);
}

[[maybe_unused]] static bool
IsNotFound(const Aws::S3::S3Errors& s3err) {
    return (s3err == Aws::S3::S3Errors::NO_SUCH_KEY ||
            s3err == Aws::S3::S3Errors::RESOURCE_NOT_FOUND);
}

/**
 * @brief user defined aws logger, redirect aws log to segcore log
 */
class AwsLogger : public Aws::Utils::Logging::FormattedLogSystem {
 public:
    AwsLogger(Aws::Utils::Logging::LogLevel log_level)
        : Aws::Utils::Logging::FormattedLogSystem(log_level) {
    }
    virtual ~AwsLogger() {
    }
    virtual void
    Flush() override {
    }

 protected:
    virtual void
    ProcessFormattedStatement(Aws::String&& statement) override;
};

/**
 * @brief This MinioChunkManager is responsible for read and write file in S3.
 */
class MinioChunkManager : public ChunkManager {
 public:
    MinioChunkManager() {
    }
    explicit MinioChunkManager(const StorageConfig& storage_config);

    MinioChunkManager(const MinioChunkManager&);
    MinioChunkManager&
    operator=(const MinioChunkManager&);

 public:
    virtual ~MinioChunkManager();

    virtual bool
    Exist(const std::string& filepath);

    virtual uint64_t
    Size(const std::string& filepath);

    virtual uint64_t
    Read(const std::string& filepath,
         uint64_t offset,
         void* buf,
         uint64_t len) {
        ThrowInfo(NotImplemented, GetName() + "Read with offset not implement");
    }

    virtual void
    Write(const std::string& filepath,
          uint64_t offset,
          void* buf,
          uint64_t len) {
        ThrowInfo(NotImplemented,
                  GetName() + "Write with offset not implement");
    }

    virtual uint64_t
    Read(const std::string& filepath, void* buf, uint64_t len);

    virtual void
    Write(const std::string& filepath, void* buf, uint64_t len);

    virtual std::vector<std::string>
    ListWithPrefix(const std::string& filepath = "");

    virtual void
    Remove(const std::string& filepath);

    virtual std::string
    GetName() const {
        return "MinioChunkManager";
    }

    virtual std::string
    GetRootPath() const {
        return remote_root_path_;
    }

    virtual std::string
    GetBucketName() const {
        return default_bucket_name_;
    }

    inline void
    SetBucketName(const std::string& bucket_name) {
        default_bucket_name_ = bucket_name;
    }

    bool
    BucketExists(const std::string& bucket_name);

    bool
    CreateBucket(const std::string& bucket_name);

    bool
    DeleteBucket(const std::string& bucket_name);

    std::vector<std::string>
    ListBuckets();

 public:
    bool
    ObjectExists(const std::string& bucket_name,
                 const std::string& object_name);
    uint64_t
    GetObjectSize(const std::string& bucket_name,
                  const std::string& object_name);
    bool
    DeleteObject(const std::string& bucket_name,
                 const std::string& object_name);
    bool
    PutObjectBuffer(const std::string& bucket_name,
                    const std::string& object_name,
                    void* buf,
                    uint64_t size);

    uint64_t
    GetObjectBuffer(const std::string& bucket_name,
                    const std::string& object_name,
                    void* buf,
                    uint64_t size);

    std::vector<std::string>
    ListObjects(const std::string& bucket_name, const std::string& prefix = "");

    void
    InitSDKAPIDefault(const std::string& log_level,
                      const std::string& tls_min_version = "");
    void
    InitSDKAPI(RemoteStorageType type,
               bool useIAM,
               const std::string& log_level,
               const std::string& tls_min_version = "");

    // Precheck whether client is configure ready or not.
    void
    PreCheck(const StorageConfig& storage_config);

    void
    ShutdownSDKAPI();
    void
    BuildS3Client(const StorageConfig& storage_config,
                  const Aws::Client::ClientConfiguration& config);
    void
    BuildAliyunCloudClient(const StorageConfig& storage_config,
                           const Aws::Client::ClientConfiguration& config);
    void
    BuildGoogleCloudClient(const StorageConfig& storage_config,
                           const Aws::Client::ClientConfiguration& config);

 protected:
    void
    BuildAccessKeyClient(const StorageConfig& storage_config,
                         const Aws::Client::ClientConfiguration& config);

    // Restrict the SDK's request/response checksum policy to WHEN_REQUIRED
    // so the V4 signer does not switch PutObject uploads to aws-chunked /
    // STREAMING-UNSIGNED-PAYLOAD-TRAILER. Required for non-AWS S3-compatible
    // backends (Aliyun OSS, GCP, Tencent COS, Huawei OBS) that reject that
    // streaming form. AWS S3 / MinIO don't need this. Mirrors milvus-storage
    // PR #500. Exposed for derived ChunkManager subclasses and unit testing.
    static void
    ApplyChecksumConfigOverrides(Aws::Client::ClientConfiguration& config);

    // Decide whether the checksum override is required for a given
    // cloud_provider. Aliyun OSS, Tencent COS, Huawei OBS, and GCP all
    // reject the streaming aws-chunked encoding the SDK adds when
    // checksums are computed; AWS S3 / MinIO accept the default. Mirrors
    // the cloud_provider-based dispatch used by milvus-storage PR #500.
    // Exposed for unit testing.
    static bool
    NeedChecksumOverride(const std::string& cloud_provider);

    Aws::SDKOptions sdk_options_;
    static std::atomic<size_t> init_count_;
    static std::mutex client_mutex_;
    std::shared_ptr<Aws::S3::S3Client> client_;
    std::string default_bucket_name_;
    std::string remote_root_path_;
    bool use_crc32c_checksum_ = false;
};

class AwsChunkManager : public MinioChunkManager {
 public:
    explicit AwsChunkManager(const StorageConfig& storage_config);
    virtual std::string
    GetName() const {
        return "AwsChunkManager";
    }
};

class GcpChunkManager : public MinioChunkManager {
 public:
    explicit GcpChunkManager(const StorageConfig& storage_config);
    virtual std::string
    GetName() const {
        return "GcpChunkManager";
    }
};

class AliyunChunkManager : public MinioChunkManager {
 public:
    explicit AliyunChunkManager(const StorageConfig& storage_config);
    virtual std::string
    GetName() const {
        return "AliyunChunkManager";
    }

    static std::shared_ptr<
        Aws::Auth::AliyunSTSAssumeRoleWebIdentityCredentialsProvider>
    GetAliyunSTSAssumeRoleWebIdentityCredentialsProvider();
};

class TencentCloudChunkManager : public MinioChunkManager {
 public:
    explicit TencentCloudChunkManager(const StorageConfig& storage_config);
    virtual std::string
    GetName() const {
        return "TencentCloudChunkManager";
    }

    static std::shared_ptr<
        Aws::Auth::TencentCloudSTSAssumeRoleWebIdentityCredentialsProvider>
    GetTencentCloudSTSAssumeRoleWebIdentityCredentialsProvider();
};

class HuaweiCloudChunkManager : public MinioChunkManager {
 public:
    explicit HuaweiCloudChunkManager(const StorageConfig& storage_config);
    virtual std::string
    GetName() const {
        return "HuaweiCloudChunkManager";
    }

    static std::shared_ptr<
        Aws::Auth::HuaweiCloudSTSAssumeRoleWebIdentityCredentialsProvider>
    GetHuaweiCloudSTSAssumeRoleWebIdentityCredentialsProvider();
};

using MinioChunkManagerPtr = std::unique_ptr<MinioChunkManager>;

static const char* TLS_FACTORY_ALLOCATION_TAG = "TlsHttpClientFactory";

static long
TlsVersionToCurlOpt(const std::string& tls_min_version) {
    if (tls_min_version == "1.0")
        return CURL_SSLVERSION_TLSv1_0;
    if (tls_min_version == "1.1")
        return CURL_SSLVERSION_TLSv1_1;
    if (tls_min_version == "1.2")
        return CURL_SSLVERSION_TLSv1_2;
    if (tls_min_version == "1.3")
        return CURL_SSLVERSION_TLSv1_3;
    return CURL_SSLVERSION_DEFAULT;
}

class TlsCurlHttpClient : public Aws::Http::CurlHttpClient {
 public:
    TlsCurlHttpClient(const Aws::Client::ClientConfiguration& config,
                      const std::string& tls_min_version)
        : CurlHttpClient(config),
          tls_ssl_version_(TlsVersionToCurlOpt(tls_min_version)) {
    }

 protected:
    void
    OverrideOptionsOnConnectionHandle(CURL* handle) const override {
        if (tls_ssl_version_ != CURL_SSLVERSION_DEFAULT) {
            curl_easy_setopt(handle, CURLOPT_SSLVERSION, tls_ssl_version_);
        }
    }

 private:
    long tls_ssl_version_;
};

class TlsHttpClientFactory : public Aws::Http::HttpClientFactory {
 public:
    explicit TlsHttpClientFactory(const std::string& tls_min_version)
        : tls_min_version_(tls_min_version) {
    }

    std::shared_ptr<Aws::Http::HttpClient>
    CreateHttpClient(
        const Aws::Client::ClientConfiguration& config) const override {
        return Aws::MakeShared<TlsCurlHttpClient>(
            TLS_FACTORY_ALLOCATION_TAG, config, tls_min_version_);
    }

    std::shared_ptr<Aws::Http::HttpRequest>
    CreateHttpRequest(
        const Aws::String& uri,
        Aws::Http::HttpMethod method,
        const Aws::IOStreamFactory& streamFactory) const override {
        return CreateHttpRequest(Aws::Http::URI(uri), method, streamFactory);
    }

    std::shared_ptr<Aws::Http::HttpRequest>
    CreateHttpRequest(
        const Aws::Http::URI& uri,
        Aws::Http::HttpMethod method,
        const Aws::IOStreamFactory& streamFactory) const override {
        auto request =
            Aws::MakeShared<Aws::Http::Standard::StandardHttpRequest>(
                TLS_FACTORY_ALLOCATION_TAG, uri, method);
        request->SetResponseStreamFactory(streamFactory);
        return request;
    }

 private:
    std::string tls_min_version_;
};

static const char* GOOGLE_CLIENT_FACTORY_ALLOCATION_TAG =
    "GoogleHttpClientFactory";

class GoogleHttpClientFactory : public Aws::Http::HttpClientFactory {
 public:
    explicit GoogleHttpClientFactory(
        std::shared_ptr<google::cloud::oauth2_internal::Credentials>
            credentials,
        const std::string& tls_min_version = "")
        : tls_min_version_(tls_min_version) {
        credentials_ = credentials;
    }

    void
    SetCredentials(std::shared_ptr<google::cloud::oauth2_internal::Credentials>
                       credentials) {
        credentials_ = credentials;
    }

    std::shared_ptr<Aws::Http::HttpClient>
    CreateHttpClient(const Aws::Client::ClientConfiguration&
                         clientConfiguration) const override {
        if (!tls_min_version_.empty() && tls_min_version_ != "default") {
            return Aws::MakeShared<TlsCurlHttpClient>(
                GOOGLE_CLIENT_FACTORY_ALLOCATION_TAG,
                clientConfiguration,
                tls_min_version_);
        }
        return Aws::MakeShared<Aws::Http::CurlHttpClient>(
            GOOGLE_CLIENT_FACTORY_ALLOCATION_TAG, clientConfiguration);
    }

    std::shared_ptr<Aws::Http::HttpRequest>
    CreateHttpRequest(
        const Aws::String& uri,
        Aws::Http::HttpMethod method,
        const Aws::IOStreamFactory& streamFactory) const override {
        return CreateHttpRequest(Aws::Http::URI(uri), method, streamFactory);
    }

    std::shared_ptr<Aws::Http::HttpRequest>
    CreateHttpRequest(
        const Aws::Http::URI& uri,
        Aws::Http::HttpMethod method,
        const Aws::IOStreamFactory& streamFactory) const override {
        auto request =
            Aws::MakeShared<Aws::Http::Standard::StandardHttpRequest>(
                GOOGLE_CLIENT_FACTORY_ALLOCATION_TAG, uri, method);
        request->SetResponseStreamFactory(streamFactory);
        auto auth_header =
            google::cloud::oauth2_internal::AuthorizationHeader(*credentials_);
        if (!auth_header.ok()) {
            ThrowInfo(IsRetryableGcpStatus(auth_header.status().code())
                          ? ErrorCode::S3Error
                          : ErrorCode::UnexpectedError,
                      fmt::format("get authorization failed, errcode: {}",
                                  google::cloud::StatusCodeToString(
                                      auth_header.status().code())));
        }
        request->SetHeaderValue(auth_header->first.c_str(),
                                auth_header->second.c_str());

        return request;
    }

 private:
    std::shared_ptr<google::cloud::oauth2_internal::Credentials> credentials_;
    std::string tls_min_version_;
};

}  // namespace milvus::storage
