// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#pragma once
#include <assert.h>
#include <folly/CancellationToken.h>
#include <stdint.h>
#include <iostream>
#include <memory>
#include <optional>
#include <string_view>
#include <type_traits>
#include <vector>

#include "segcore/Utils.h"
#include <utility>
#include "PlanNodeVisitor.h"
#include "common/Consts.h"
#include "common/EasyAssert.h"
#include "common/OpContext.h"
#include "common/QueryResult.h"
#include "common/Tracer.h"
#include "common/Types.h"
#include "common/Vector.h"
#include "exec/QueryContext.h"
#include "exec/expression/Utils.h"
#include "plan/PlanNode.h"
#include "query/PlanImpl.h"
#include "query/PlanNode.h"
#include "segcore/SegmentInterface.h"

namespace milvus::query {

inline ColumnVectorPtr
GetColumnVectorForTest(const VectorPtr& result) {
    if (auto convert_vector = std::dynamic_pointer_cast<ColumnVector>(result)) {
        return convert_vector;
    }

    if (result != nullptr &&
        std::string_view(typeid(*result).name()) ==
            std::string_view(typeid(ColumnVector).name())) {
        return std::static_pointer_cast<ColumnVector>(result);
    }

    return milvus::exec::GetColumnVector(result);
}

class ExecPlanNodeVisitor : public PlanNodeVisitor {
 public:
    void
    visit(VectorPlanNode& node) override;

    void
    visit(RetrievePlanNode& node) override;

    // no extra visit for vector types

 public:
    ExecPlanNodeVisitor(const segcore::SegmentInterface& segment,
                        Timestamp timestamp,
                        const PlaceholderGroup* placeholder_group,
                        const folly::CancellationToken& cancel_token =
                            folly::CancellationToken(),
                        int32_t consistency_level = 0,
                        Timestamp collection_ttl = 0,
                        int64_t entity_ttl_physical_time_us = 0,
                        milvus::tracer::SpanPtr trace_span = nullptr)
        : segment_(segment),
          timestamp_(timestamp),
          entity_ttl_physical_time_us_(
              entity_ttl_physical_time_us > 0
                  ? entity_ttl_physical_time_us
                  : static_cast<int64_t>(
                        milvus::segcore::TimestampToPhysicalMs(timestamp)) *
                        1000),
          placeholder_group_(placeholder_group),
          cancel_token_(cancel_token),
          consistency_level_(consistency_level),
          collection_ttl_timestamp_(collection_ttl),
          trace_span_(std::move(trace_span)) {
    }

    // Only used for test
    ExecPlanNodeVisitor(const segcore::SegmentInterface& segment,
                        Timestamp timestamp,
                        const folly::CancellationToken& cancel_token =
                            folly::CancellationToken(),
                        int32_t consistency_level = 0,
                        Timestamp collection_ttl = 0,
                        int64_t entity_ttl_physical_time_us = 0)
        : segment_(segment),
          timestamp_(timestamp),
          entity_ttl_physical_time_us_(
              entity_ttl_physical_time_us > 0
                  ? entity_ttl_physical_time_us
                  : static_cast<int64_t>(
                        milvus::segcore::TimestampToPhysicalMs(timestamp)) *
                        1000),
          cancel_token_(cancel_token),
          consistency_level_(consistency_level),
          collection_ttl_timestamp_(collection_ttl) {
        placeholder_group_ = nullptr;
    }

    SearchResult
    get_moved_result(PlanNode& node) {
        assert(!search_result_opt_.has_value());
        node.accept(*this);
        assert(search_result_opt_.has_value());
        auto ret = std::move(search_result_opt_).value();
        search_result_opt_.reset();
        search_result_opt_ = std::nullopt;
        return ret;
    }

    RetrieveResult
    get_retrieve_result(PlanNode& node) {
        assert(!retrieve_result_opt_.has_value());
        std::cout.flush();
        node.accept(*this);
        assert(retrieve_result_opt_.has_value());
        auto ret = std::move(retrieve_result_opt_).value();
        retrieve_result_opt_.reset();
        retrieve_result_opt_ = std::nullopt;
        return ret;
    }

    void
    SetExprUsePkIndex(bool use_pk_index) {
        expr_use_pk_index_ = use_pk_index;
    }

    bool
    GetExprUsePkIndex() {
        return expr_use_pk_index_;
    }

    void
    SetFilterOnly(bool filter_only) {
        filter_only_ = filter_only;
    }

    bool
    GetFilterOnly() {
        return filter_only_;
    }

    ExecPlanNodeVisitor&
    SetEnableExprCache(bool enable) {
        enable_expr_cache_ = enable;
        return *this;
    }

    bool
    GetEnableExprCache() {
        return enable_expr_cache_;
    }

    static RowVectorPtr
    ExecuteTask(plan::PlanFragment& plan,
                std::shared_ptr<milvus::exec::QueryContext> query_context);

    void
    setupRetrieveResult(
        const RowVectorPtr& result,
        const OpContext& op_context,
        const RetrievePlanNode& node,
        RetrieveResult& tmp_retrieve_result,
        const segcore::SegmentInternalInterface* segment,
        std::shared_ptr<milvus::exec::QueryContext> query_context);

 private:
    const segcore::SegmentInterface& segment_;
    Timestamp timestamp_;
    int64_t entity_ttl_physical_time_us_;
    const PlaceholderGroup* placeholder_group_;
    folly::CancellationToken cancel_token_;
    int32_t consistency_level_ = 0;
    Timestamp collection_ttl_timestamp_;

    SearchResultOpt search_result_opt_;
    RetrieveResultOpt retrieve_result_opt_;

    bool expr_use_pk_index_ = false;
    bool filter_only_ = false;
    bool enable_expr_cache_ = false;
    milvus::tracer::SpanPtr trace_span_ = nullptr;
};

namespace {

// for test use only - shared implementation. pin_snapshot mirrors the
// production visit() path: capture the sealed published snapshot exactly once
// per request so the expression hot loop reads from the pinned immutable state
// instead of self-capturing on every chunk access.
inline BitsetType
ExecuteQueryExprImpl(std::shared_ptr<milvus::plan::PlanNode> plannode,
                     const milvus::segcore::SegmentInternalInterface* segment,
                     uint64_t active_count,
                     uint64_t timestamp,
                     int64_t entity_ttl_physical_time_us,
                     bool pin_snapshot) {
    auto plan_fragment = plan::PlanFragment(plannode);

    auto query_context = std::make_shared<milvus::exec::QueryContext>(
        DEAFULT_QUERY_ID,
        segment,
        active_count,
        timestamp,
        0,
        0,
        milvus::query::PlanOptions(),
        std::make_shared<milvus::exec::QueryConfig>(),
        nullptr,
        std::unordered_map<std::string,
                           std::shared_ptr<milvus::exec::BaseConfig>>(),
        entity_ttl_physical_time_us);
    if (pin_snapshot) {
        query_context->set_read_snapshot(segment->CaptureReadSnapshot());
    }
    auto row = ExecPlanNodeVisitor::ExecuteTask(plan_fragment, query_context);
    AssertInfo(row != nullptr,
               "ExecuteTask returned null row vector for query expression");
    AssertInfo(
        row->childrens().size() == 1,
        "query expr operator's result vector's children size not equal one");
    auto col_vec = milvus::query::GetColumnVectorForTest(row->childrens()[0]);
    AssertInfo(col_vec != nullptr, "failed to cast to ColumnVector");
    BitsetTypeView view(col_vec->GetRawData(), col_vec->size());
    BitsetType query_view(view);
    query_view.flip();
    return query_view;
}

}  // namespace

// for test use only
inline BitsetType
ExecuteQueryExpr(std::shared_ptr<milvus::plan::PlanNode> plannode,
                 const milvus::segcore::SegmentInternalInterface* segment,
                 uint64_t active_count,
                 uint64_t timestamp) {
    return ExecuteQueryExprImpl(
        std::move(plannode), segment, active_count, timestamp, 0, false);
}

// for test use only - with explicit entity_ttl_physical_time_us
inline BitsetType
ExecuteQueryExpr(std::shared_ptr<milvus::plan::PlanNode> plannode,
                 const milvus::segcore::SegmentInternalInterface* segment,
                 uint64_t active_count,
                 uint64_t timestamp,
                 int64_t entity_ttl_physical_time_us) {
    return ExecuteQueryExprImpl(std::move(plannode),
                                segment,
                                active_count,
                                timestamp,
                                entity_ttl_physical_time_us,
                                false);
}

// for test use only - pin the sealed read snapshot once per request
inline BitsetType
ExecuteQueryExpr(std::shared_ptr<milvus::plan::PlanNode> plannode,
                 const milvus::segcore::SegmentInternalInterface* segment,
                 uint64_t active_count,
                 uint64_t timestamp,
                 bool pin_snapshot) {
    return ExecuteQueryExprImpl(
        std::move(plannode), segment, active_count, timestamp, 0, pin_snapshot);
}

}  // namespace milvus::query
