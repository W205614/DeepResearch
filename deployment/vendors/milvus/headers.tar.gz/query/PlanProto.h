// Copyright (C) 2019-2020 Zilliz. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License
// is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
// or implied. See the License for the specific language governing permissions and limitations under the License

#pragma once

#include <boost/dynamic_bitset.hpp>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>

#include "Plan.h"
#include "PlanNode.h"
#include "common/Schema.h"
#include "expr/ITypeExpr.h"
#include "pb/plan.pb.h"
#include "rescores/Scorer.h"

namespace milvus::query {

// Returns a bounded plan-proto diagnostic string with client-supplied
// membership blobs replaced by size markers. Intended only for debug logging.
std::string
PlanProtoDebugString(const proto::plan::PlanNode& plan_node_proto);

class ProtoParser {
 public:
    using TypeCheckFunction = std::function<bool(const DataType)>;
    static bool
    TypeIsBool(const DataType type) {
        return type == DataType::BOOL;
    }
    static bool
    TypeIsAny(const DataType) {
        return true;
    }

 public:
    explicit ProtoParser(SchemaPtr schema) : schema(std::move(schema)) {
    }

    std::unique_ptr<VectorPlanNode>
    PlanNodeFromProto(const proto::plan::PlanNode& plan_node_proto);

    std::unique_ptr<RetrievePlanNode>
    RetrievePlanNodeFromProto(const proto::plan::PlanNode& plan_node_proto);

    std::unique_ptr<Plan>
    CreatePlan(const proto::plan::PlanNode& plan_node_proto);

    std::unique_ptr<Plan>
    CreatePlan(std::unique_ptr<proto::plan::PlanNode> plan_node_proto);

    std::unique_ptr<RetrievePlan>
    CreateRetrievePlan(const proto::plan::PlanNode& plan_node_proto);

    std::unique_ptr<RetrievePlan>
    CreateRetrievePlan(std::unique_ptr<proto::plan::PlanNode> plan_node_proto);

    expr::TypedExprPtr
    ParseExprs(const proto::plan::Expr& expr_pb,
               TypeCheckFunction type_check = TypeIsBool);

    std::shared_ptr<rescores::Scorer>
    ParseScorer(const proto::plan::ScoreFunction& function);

    std::shared_ptr<rescores::Scorer>
    ParseScorer(std::unique_ptr<proto::plan::ScoreFunction> function);

    // Extract only filter-related nodes (FilterBitsNode, ElementFilterBitsNode)
    // from a plan tree, avoiding VectorSearchNode, SearchGroupByNode, etc.
    // Returns MvccNode only if no pre-filter nodes are found.
    static std::shared_ptr<plan::PlanNode>
    ExtractFilterOnlyPlan(const std::shared_ptr<plan::PlanNode>& root_node);

 private:
    using BloomBlobOwners =
        std::unordered_map<const std::string*,
                           std::shared_ptr<const std::string>>;

    ProtoParser(SchemaPtr schema, BloomBlobOwners bloom_blob_owners)
        : schema(std::move(schema)),
          bloom_blob_owners_(std::move(bloom_blob_owners)) {
    }

    std::unique_ptr<Plan>
    CreatePlanImpl(const proto::plan::PlanNode& plan_node_proto);

    std::unique_ptr<RetrievePlan>
    CreateRetrievePlanImpl(const proto::plan::PlanNode& plan_node_proto);

    expr::TypedExprPtr
    CreateAlwaysTrueExprs();

    expr::TypedExprPtr
    ParseBinaryExprs(const proto::plan::BinaryExpr& expr_pb);

    expr::TypedExprPtr
    ParseBinaryArithOpEvalRangeExprs(
        const proto::plan::BinaryArithOpEvalRangeExpr& expr_pb);

    expr::TypedExprPtr
    ParseBinaryRangeExprs(const proto::plan::BinaryRangeExpr& expr_pb);

    expr::TypedExprPtr
    ParseCallExprs(const proto::plan::CallExpr& expr_pb);

    expr::TypedExprPtr
    ParseColumnExprs(const proto::plan::ColumnExpr& expr_pb);

    expr::TypedExprPtr
    ParseCompareExprs(const proto::plan::CompareExpr& expr_pb);

    expr::TypedExprPtr
    ParseExistExprs(const proto::plan::ExistsExpr& expr_pb);

    expr::TypedExprPtr
    ParseNullExprs(const proto::plan::NullExpr& expr_pb);

    expr::TypedExprPtr
    ParseJsonContainsExprs(const proto::plan::JSONContainsExpr& expr_pb);

    expr::TypedExprPtr
    ParseGISFunctionFilterExprs(
        const proto::plan::GISFunctionFilterExpr& expr_pb);

    expr::TypedExprPtr
    ParseTermExprs(const proto::plan::TermExpr& expr_pb);

    expr::TypedExprPtr
    ParseUnaryExprs(const proto::plan::UnaryExpr& expr_pb);

    expr::TypedExprPtr
    ParseUnaryRangeExprs(const proto::plan::UnaryRangeExpr& expr_pb);

    expr::TypedExprPtr
    ParseTimestamptzArithCompareExprs(
        const proto::plan::TimestamptzArithCompareExpr& expr_pb);

    expr::TypedExprPtr
    ParseMatchExprs(const proto::plan::MatchExpr& expr_pb);

    expr::TypedExprPtr
    ParseBloomFilterExprs(const proto::plan::BloomFilterExpr& expr_pb);

    expr::TypedExprPtr
    ParseRoaringFilterExprs(const proto::plan::RoaringFilterExpr& expr_pb);

    expr::TypedExprPtr
    ParseValueExprs(const proto::plan::ValueExpr& expr_pb);

    void
    PlanOptionsFromProto(const proto::plan::PlanOption& plan_option_proto,
                         PlanOptions& plan_options);

    SearchInfo
    ParseSearchInfo(const proto::plan::VectorANNS& anns_proto);

 private:
    const SchemaPtr schema;
    // Owner-bound entry points move each Bloom string out of their uniquely
    // owned protobuf root. The map ties the original string object's address
    // to its new shared owner only while the root is being parsed; logical
    // expressions retain the shared strings they consume. Legacy const-ref
    // entry points leave this empty and keep their safe-copy behavior.
    const BloomBlobOwners bloom_blob_owners_;
};

}  // namespace milvus::query

template <>
struct fmt::formatter<milvus::proto::plan::GenericValue::ValCase>
    : formatter<string_view> {
    auto
    format(milvus::proto::plan::GenericValue::ValCase c,
           format_context& ctx) const {
        string_view name = "unknown";
        switch (c) {
            case milvus::proto::plan::GenericValue::ValCase::kBoolVal:
                name = "kBoolVal";
                break;
            case milvus::proto::plan::GenericValue::ValCase::kInt64Val:
                name = "kInt64Val";
                break;
            case milvus::proto::plan::GenericValue::ValCase::kFloatVal:
                name = "kFloatVal";
                break;
            case milvus::proto::plan::GenericValue::ValCase::kStringVal:
                name = "kStringVal";
                break;
            case milvus::proto::plan::GenericValue::ValCase::kArrayVal:
                name = "kArrayVal";
                break;
            case milvus::proto::plan::GenericValue::ValCase::VAL_NOT_SET:
                name = "VAL_NOT_SET";
                break;
        }
        return formatter<string_view>::format(name, ctx);
    }
};
