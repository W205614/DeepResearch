// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <stdint.h>
#include <memory>
#include <string>
#include <vector>

#include "common/Promise.h"
#include "common/Vector.h"
#include "common/protobuf_utils.h"
#include "exec/Driver.h"
#include "exec/operator/Operator.h"
#include "pb/plan.pb.h"
#include "plan/PlanNode.h"
#include "rescores/Scorer.h"

// difference between FilterBitsNode and RescoresNode is that
// FilterBitsNode will go through whole segment and return bitset to indicate which offset is filtered out or not
// RescoresNode will accept offsets array and execute over these and generate result valid offsets
namespace milvus::exec {
class PhyRescoresNode : public Operator {
 public:
    PhyRescoresNode(int32_t operator_id,
                    DriverContext* ctx,
                    const std::shared_ptr<const plan::RescoresNode>& scorer);

    bool
    IsFilter() const override {
        return true;
    }

    bool
    NeedInput() const override {
        return !is_finished_;
    }

    void
    AddInput(RowVectorPtr& input) override;

    RowVectorPtr
    GetOutput() override;

    bool
    IsFinished() override;

    void
    Close() override {
        Operator::Close();
    }

    BlockingReason
    IsBlocked(ContinueFuture* /* unused */) override {
        return BlockingReason::kNotBlocked;
    }

    virtual std::string
    ToString() const override {
        return "PhyRescoresNode";
    }

 private:
    std::vector<std::shared_ptr<rescores::Scorer>> scorers_;
    const proto::plan::ScoreOption* option_;
    bool is_finished_{false};
};
}  // namespace milvus::exec
