// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <fmt/core.h>
#include <stdint.h>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "cachinglayer/CacheSlot.h"
#include "common/EasyAssert.h"
#include "common/OpContext.h"
#include "common/Schema.h"
#include "common/Utils.h"
#include "common/Vector.h"
#include "common/protobuf_utils.h"
#include "common/type_c.h"
#include "exec/expression/EvalCtx.h"
#include "exec/expression/Expr.h"
#include "expr/ITypeExpr.h"
#include "index/Index.h"
#include "segcore/SegmentChunkReader.h"
#include "segcore/SegmentInterface.h"

namespace milvus {
namespace exec {

class PhyColumnExpr : public Expr {
 public:
    PhyColumnExpr(std::vector<std::shared_ptr<Expr>> input,
                  const std::shared_ptr<const milvus::expr::ColumnExpr>& expr,
                  const std::string& name,
                  milvus::OpContext* op_ctx,
                  const segcore::SegmentInternalInterface* segment,
                  int64_t active_count,
                  int64_t batch_size)
        : Expr(expr->type(), std::move(input), name, op_ctx),
          segment_chunk_reader_(op_ctx, segment, active_count),
          batch_size_(batch_size),
          expr_(expr) {
        auto schema = segment->get_schema_snapshot();
        auto& field_meta = (*schema)[expr_->GetColumn().field_id_];
        pinned_index_ = PinIndex(op_ctx_, segment, field_meta);
        is_indexed_ = pinned_index_.size() > 0;
        use_index_data_ =
            is_indexed_ &&
            segment->HasRawData(expr_->GetColumn().field_id_.get());
        if (segment->is_chunked()) {
            num_chunk_ =
                use_index_data_
                    ? pinned_index_.size()
                    : segment->num_chunk_data(expr_->GetColumn().field_id_);
        } else {
            num_chunk_ = use_index_data_
                             ? pinned_index_.size()
                             : upper_div(segment_chunk_reader_.active_count_,
                                         segment_chunk_reader_.SizePerChunk());
        }
        AssertInfo(
            batch_size_ > 0,
            fmt::format("expr batch size should greater than zero, but now: {}",
                        batch_size_));
    }

    void
    Eval(EvalCtx& context, VectorPtr& result) override;

    void
    MoveCursor() override {
        if (!has_offset_input_) {
            if (segment_chunk_reader_.segment_->is_chunked()) {
                if (use_index_data_) {
                    MoveCursorForIndexed();
                } else {
                    segment_chunk_reader_.MoveCursorForMultipleChunk(
                        current_chunk_id_,
                        current_chunk_pos_,
                        expr_->GetColumn().field_id_,
                        num_chunk_,
                        batch_size_);
                }
            } else {
                segment_chunk_reader_.MoveCursorForSingleChunk(
                    current_chunk_id_,
                    current_chunk_pos_,
                    num_chunk_,
                    batch_size_);
            }
        }
    }

    void
    SetSnapshot(const segcore::SegmentReadSnapshot* snapshot) override {
        segment_chunk_reader_.SetSnapshot(snapshot);
    }

    void
    MoveCursorForIndexed() {
        current_chunk_pos_ = current_chunk_pos_ + batch_size_ >=
                                     segment_chunk_reader_.active_count_
                                 ? segment_chunk_reader_.active_count_
                                 : current_chunk_pos_ + batch_size_;
    }

 private:
    int64_t
    GetCurrentRows() const {
        if (segment_chunk_reader_.segment_->is_chunked()) {
            auto current_rows =
                use_index_data_ && segment_chunk_reader_.segment_->type() ==
                                       SegmentType::Sealed
                    ? current_chunk_pos_
                    : segment_chunk_reader_.NumRowsUntilChunk(
                          expr_->GetColumn().field_id_, current_chunk_id_) +
                          current_chunk_pos_;
            return current_rows;
        } else {
            return segment_chunk_reader_.segment_->type() ==
                           SegmentType::Growing
                       ? current_chunk_id_ *
                                 segment_chunk_reader_.SizePerChunk() +
                             current_chunk_pos_
                       : current_chunk_pos_;
        }
    }

    int64_t
    GetNextBatchSize();

    template <typename T>
    VectorPtr
    DoEval(OffsetVector* input = nullptr);

    std::string
    ToString() const override {
        return fmt::format("{}", expr_->ToString());
    }

    bool
    IsSource() const override {
        return true;
    }

    std::optional<milvus::expr::ColumnInfo>
    GetColumnInfo() const override {
        return expr_->GetColumn();
    }

    bool
    CanExecuteAllAtOnce() const override {
        return false;
    }

    segcore::PinnedIndexView
    PinnedIndexForRawLookup() const {
        if (!use_index_data_) {
            return {};
        }
        return {pinned_index_.data(), pinned_index_.size()};
    }

    bool is_indexed_;
    bool use_index_data_;

    int64_t num_chunk_{0};
    int64_t current_chunk_id_{0};
    int64_t current_chunk_pos_{0};

    const segcore::SegmentChunkReader segment_chunk_reader_;
    int64_t batch_size_;
    std::shared_ptr<const milvus::expr::ColumnExpr> expr_;
    std::vector<PinWrapper<const index::IndexBase*>> pinned_index_;
};

}  //namespace exec
}  // namespace milvus
