// Licensed to the LF AI & Data foundation under one
// or more contributor license agreements. See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership. The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <stdint.h>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "common/OpContext.h"
#include "common/Types.h"
#include "common/Vector.h"
#include "common/protobuf_utils.h"
#include "exec/expression/EvalCtx.h"
#include "exec/expression/Expr.h"
#include "expr/ITypeExpr.h"
#include "segcore/SegmentInterface.h"

namespace milvus {
namespace exec {

class PhyAlwaysTrueExpr : public Expr {
 public:
    PhyAlwaysTrueExpr(
        std::vector<std::shared_ptr<Expr>> input,
        const std::shared_ptr<const milvus::expr::AlwaysTrueExpr>& expr,
        const std::string& name,
        milvus::OpContext* op_ctx,
        const segcore::SegmentInternalInterface* segment,
        int64_t active_count,
        int64_t batch_size)
        : Expr(DataType::BOOL, std::move(input), name, op_ctx),
          expr_(expr),
          active_count_(active_count),
          batch_size_(batch_size) {
    }

    void
    Eval(EvalCtx& context, VectorPtr& result) override;

    void
    MoveCursor() override {
        if (!has_offset_input_) {
            int64_t real_batch_size =
                current_pos_ + batch_size_ >= active_count_
                    ? active_count_ - current_pos_
                    : batch_size_;

            current_pos_ += real_batch_size;
        }
    }

    std::string
    ToString() const override {
        return "[AlwaysTrue]";
    }

    bool
    IsSource() const override {
        return true;
    }

    std::optional<milvus::expr::ColumnInfo>
    GetColumnInfo() const override {
        return std::nullopt;
    }

    bool
    CanExecuteAllAtOnce() const override {
        return true;
    }

    void
    SetExecuteAllAtOnce() override {
        batch_size_ = active_count_;
    }

 private:
    std::shared_ptr<const milvus::expr::AlwaysTrueExpr> expr_;
    int64_t active_count_;
    int64_t current_pos_{0};
    int64_t batch_size_;
};

}  //namespace exec
}  // namespace milvus
