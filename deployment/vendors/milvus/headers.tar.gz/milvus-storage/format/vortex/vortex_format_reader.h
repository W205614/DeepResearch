// Copyright 2023 Zilliz
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include <arrow/chunked_array.h>
#include <arrow/c/abi.h>

#include "milvus-storage/common/config.h"
#include "milvus-storage/format/format_reader.h"
#include "milvus-storage/filesystem/ffi/filesystem_internal.h"

namespace milvus_storage::vortex {

class VortexFile;
struct VortexReadPlan;
namespace ffi {
struct CoalescingWindow;
}  // namespace ffi
extern const ffi::CoalescingWindow kSmallCoalescingWindow;
namespace expr {
class Expr;
}  // namespace expr

class VortexFormatReader final : public FormatReader, public std::enable_shared_from_this<VortexFormatReader> {
  public:
  struct MetaTrait {
    struct Payload {
      std::shared_ptr<FileSystemWrapper> fs_holder;
      std::shared_ptr<VortexFile> vxfile;
      uint64_t logical_chunk_rows = 0;
      std::shared_ptr<const std::vector<uint64_t>> column_memory_weights;
      api::Properties properties;
    };

    using Metadata = FormatReaderMetadata<Payload>;
    using MetadataPtr = std::shared_ptr<const Metadata>;

    static std::string cache_key(const api::ColumnGroupFile& file);

    static arrow::Result<MetadataPtr> load_metadata(const api::ColumnGroupFile& file,
                                                    const api::Properties& properties,
                                                    const KeyRetriever& key_retriever);

    // Open on the shared Tokio runtime and return immutable metadata for cache reuse.
    static folly::SemiFuture<arrow::Result<MetadataPtr>> load_metadata_async(const api::ColumnGroupFile& file,
                                                                             const api::Properties& properties,
                                                                             const KeyRetriever& key_retriever);

    static arrow::Result<std::shared_ptr<VortexFormatReader>> create_from_metadata(
        MetadataPtr metadata,
        const api::ColumnGroupFile& file,
        const std::shared_ptr<arrow::Schema>& read_schema,
        const std::vector<std::string>& needed_columns,
        const std::string& predicate);
    static folly::SemiFuture<arrow::Result<std::shared_ptr<VortexFormatReader>>> create_from_metadata_async(
        MetadataPtr metadata,
        const api::ColumnGroupFile& file,
        const std::shared_ptr<arrow::Schema>& read_schema,
        const std::vector<std::string>& needed_columns,
        const std::string& predicate);

 private:
    // Implementation detail, not part of FormatReaderWithMetadata. This helper
    // lives in the nested MetaTrait only to access the reader's private state.
    static arrow::Result<MetadataPtr> create_metadata_from_reader(const std::shared_ptr<VortexFormatReader>& reader,
                                                                  const api::ColumnGroupFile& file);
  };

  VortexFormatReader(const std::shared_ptr<arrow::fs::FileSystem>& fs,
                     const std::shared_ptr<arrow::Schema>& schema,
                     const std::string& path,
                     const milvus_storage::api::Properties& properties,
                     const std::vector<std::string>& needed_columns,
                     uint64_t file_size = 0,
                     uint64_t footer_size = 0);
  // Defined in the cpp because vxfile_ is a unique_ptr to a forward-declared VortexFile.
  ~VortexFormatReader() override;

  [[nodiscard]] arrow::Status open() override;
  // Open the Vortex file on the shared Tokio runtime and retain this reader until callback.
  [[nodiscard]] folly::SemiFuture<arrow::Status> open_async() override;

  // get the row group infos
  [[nodiscard]] arrow::Result<std::vector<RowGroupInfo>> get_row_group_infos() override;

  [[nodiscard]] arrow::Result<std::vector<uint64_t>> get_rg_column_memsz(int64_t row_group_index) const override;

  // get the chunk
  [[nodiscard]] arrow::Result<std::shared_ptr<arrow::RecordBatch>> get_chunk(const int& row_group_index) override;

  // get the chunks
  [[nodiscard]] arrow::Result<std::vector<std::shared_ptr<arrow::RecordBatch>>> get_chunks(
      const std::vector<int>& rg_indices_in_file) override;

  // take
  [[nodiscard]] arrow::Result<std::shared_ptr<arrow::Table>> take(const std::vector<int64_t>& row_indices) override;

  // read with range
  [[nodiscard]] arrow::Result<std::shared_ptr<arrow::RecordBatchReader>> read_with_range(
      const uint64_t& start_offset, const uint64_t& end_offset) override;

  // Execute a sparse file-local row selection on Tokio and complete after all
  // selected batches have been materialized.
  [[nodiscard]] folly::SemiFuture<arrow::Result<std::shared_ptr<arrow::Table>>> take_async(
      const std::vector<int64_t>& row_indices) override;

  // Execute projection/filter/range on Tokio. The returned reader wraps batches
  // already collected by the Rust task rather than a live stream.
  [[nodiscard]] folly::SemiFuture<arrow::Result<std::shared_ptr<arrow::RecordBatchReader>>> read_with_range_async(
      uint64_t start_offset, uint64_t end_offset) override;

  [[nodiscard]] arrow::Result<std::shared_ptr<FormatReader>> clone_reader() override;

  [[nodiscard]] std::shared_ptr<arrow::Schema> get_schema() const override;

  [[nodiscard]] arrow::Status set_predicate(const std::string& predicate) override;

  // get the row ranges(splits) of the file
  [[nodiscard]] arrow::Result<std::vector<uint64_t>> row_ranges() const;

  // get the total rows of the file
  size_t rows() const;

  // get the total memory usage(uncompressed memory) of the file
  arrow::Result<uint64_t> total_mem_usage();

  [[nodiscard]] arrow::Result<std::shared_ptr<arrow::RecordBatchReader>> streaming_read(
      uint64_t row_start, uint64_t row_end, const ffi::CoalescingWindow& coalescing_window);

  [[nodiscard]] arrow::Result<std::shared_ptr<arrow::ChunkedArray>> blocking_read(
      uint64_t row_start, uint64_t row_end, const ffi::CoalescingWindow& coalescing_window);

  // Vortex-specific extension: execute a planner-generated scan plan while keeping
  // the existing FormatReader interfaces unchanged.
  [[nodiscard]] arrow::Result<ArrowArrayStream> read_with_plan(const VortexReadPlan& plan);

  // Vortex-specific extension: execute a planner-generated scan plan and return
  // the original file-local row indices matching the plan.
  [[nodiscard]] arrow::Result<ArrowArrayStream> read_row_ids_with_plan(const VortexReadPlan& plan);

  private:
  [[nodiscard]] static arrow::Result<std::optional<bool>> parse_split_row_indices_override(const std::string& mode);

  [[nodiscard]] arrow::Result<std::shared_ptr<arrow::Schema>> output_schema() const;

  VortexFormatReader(MetaTrait::MetadataPtr metadata,
                     uint64_t file_size,
                     uint64_t footer_size,
                     const std::shared_ptr<arrow::Schema>& read_schema,
                     const std::vector<std::string>& needed_columns);

  [[nodiscard]] arrow::Result<ArrowArrayStream> read(uint64_t row_start,
                                                     uint64_t row_end,
                                                     const ffi::CoalescingWindow& coalescing_window);

  private:
  std::shared_ptr<FileSystemWrapper> fs_holder_;
  std::vector<std::string> proj_cols_;
  std::string path_;
  std::shared_ptr<arrow::Schema> read_schema_;
  milvus_storage::api::Properties properties_;
  uint64_t file_size_ = 0;    ///< Pre-known file size to skip S3 HEAD requests
  uint64_t footer_size_ = 0;  ///< Pre-known footer size for single-IO footer read
  std::optional<bool> split_row_indices_;

  std::shared_ptr<arrow::Schema> file_schema_;  // always derived from file in open()

  uint64_t logical_chunk_rows_ = 0;
  std::shared_ptr<const std::vector<uint64_t>> column_memory_weights_;
  std::vector<RowGroupInfo> row_group_infos_;
  std::shared_ptr<VortexFile> vxfile_;
  std::unique_ptr<expr::Expr> parsed_predicate_;
};

}  // namespace milvus_storage::vortex
