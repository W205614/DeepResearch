// Copyright 2023 Zilliz
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <memory>

#include <arrow/filesystem/filesystem.h>
#include <arrow/table.h>
#include <arrow/type.h>
#include <arrow/util/key_value_metadata.h>
#include <parquet/arrow/writer.h>

#include "milvus-storage/common/config.h"
#include "milvus-storage/common/metadata.h"
#include "milvus-storage/format/format_writer.h"
#include "milvus-storage/properties.h"
#include "milvus-storage/column_groups.h"

namespace milvus_storage::parquet {

class ParquetFileWriter : public FormatWriter {
  public:
  static arrow::Result<std::unique_ptr<ParquetFileWriter>> Make(std::shared_ptr<arrow::fs::FileSystem> fs,
                                                                std::shared_ptr<arrow::Schema> schema,
                                                                const std::string& file_path,
                                                                const api::Properties& properties);

  static arrow::Result<std::unique_ptr<ParquetFileWriter>> Make(
      std::shared_ptr<arrow::Schema> schema,
      std::shared_ptr<arrow::fs::FileSystem> fs,
      const std::string& file_path,
      const milvus_storage::StorageConfig& storage_config,
      const std::shared_ptr<::parquet::WriterProperties>& writer_props = ::parquet::default_writer_properties());

  protected:
  ParquetFileWriter(
      std::shared_ptr<arrow::Schema> schema,
      std::shared_ptr<arrow::fs::FileSystem> fs,
      const std::string& file_path,
      const milvus_storage::StorageConfig& storage_config,
      const std::shared_ptr<::parquet::WriterProperties>& writer_props = ::parquet::default_writer_properties());

  arrow::Status init();

  public:
  ~ParquetFileWriter() override = default;

  arrow::Status Write(const std::shared_ptr<arrow::RecordBatch> record) override;

  arrow::Status Flush() override;

  arrow::Result<api::ColumnGroupFile> Close() override;

  arrow::Result<size_t> Tell() const;

  arrow::Status AppendKVMetadata(const std::string& key, const std::string& value);

  arrow::Status AddUserMetadata(const std::vector<std::pair<std::string, std::string>>& metadata);

  private:
  arrow::Status write_row_group(const std::vector<std::shared_ptr<arrow::RecordBatch>>& batch, size_t group_size);

  std::shared_ptr<arrow::fs::FileSystem> fs_;
  std::shared_ptr<arrow::Schema> schema_;
  const std::string file_path_;
  milvus_storage::StorageConfig storage_config_;

  std::shared_ptr<arrow::io::OutputStream> sink_;
  std::unique_ptr<::parquet::arrow::FileWriter> writer_;
  std::shared_ptr<arrow::KeyValueMetadata> kv_metadata_;

  milvus_storage::RowGroupMetadataVector row_group_metadata_;
  std::shared_ptr<::parquet::WriterProperties> writer_props_;

  // Cache for batches waiting to be written
  std::vector<std::shared_ptr<arrow::RecordBatch>> cached_batches_;
  size_t cached_size_ = 0;
  std::vector<size_t> cached_batch_sizes_;
  bool closed_ = false;
  size_t cached_tell_ = 0;

  int64_t written_rows_ = 0;
};
}  // namespace milvus_storage::parquet
