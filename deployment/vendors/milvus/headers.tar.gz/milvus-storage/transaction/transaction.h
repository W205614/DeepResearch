// Copyright 2023 Zilliz
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <cstdint>
#include <string>
#include <memory>
#include <vector>
#include <map>

#include <arrow/status.h>

#include "milvus-storage/filesystem/fs.h"
#include "milvus-storage/manifest.h"

namespace milvus_storage::api::transaction {

/**
 * @brief Version constant for fetching the latest manifest
 *
 * When used as a version parameter, LATEST means to fetch the greatest version number.
 * If no manifests exist, the system will generate version 1.
 */
static constexpr int64_t LATEST = -1;

/**
 * @brief Transaction updates tracking class
 *
 * Records all changes made during a transaction that can be used by the resolver
 * Implementation is in transaction.cpp
 */
class Updates {
  public:
  Updates();
  ~Updates();

  [[nodiscard]] bool hasChanges() const;
  void AddColumnGroup(const std::shared_ptr<ColumnGroup>& cg);
  void AppendFiles(const std::vector<std::shared_ptr<ColumnGroup>>& cgs);
  void AddDeltaLog(const DeltaLog& delta_log);
  void UpdateStat(const std::string& key, const Statistics& stat);
  void AddIndex(const Index& index);
  void DropColumn(const std::string& column_name);
  void DropIndex(int64_t index_id);
  void AddLobFile(const LobFileInfo& lob_file);
  [[nodiscard]] const std::vector<std::shared_ptr<ColumnGroup>>& GetAddedColumnGroups() const;
  [[nodiscard]] const std::vector<std::vector<std::shared_ptr<ColumnGroup>>>& GetAppendedFiles() const;
  [[nodiscard]] const std::vector<DeltaLog>& GetAddedDeltaLogs() const;
  [[nodiscard]] const std::map<std::string, Statistics>& GetAddedStats() const;
  [[nodiscard]] const std::vector<Index>& GetAddedIndexes() const;
  [[nodiscard]] const std::vector<std::string>& GetDroppedColumns() const;
  [[nodiscard]] const std::vector<int64_t>& GetDroppedIndexes() const;
  [[nodiscard]] const std::vector<LobFileInfo>& GetAddedLobFiles() const;

  private:
  // Column changes
  std::vector<std::string> dropped_columns_;  // Column names to drop

  // Column group changes
  ColumnGroups added_column_groups_;          // New column groups to add
  std::vector<ColumnGroups> appended_files_;  // Column groups with files to append

  // Delta log changes
  std::vector<DeltaLog> added_delta_logs_;  // New delta logs to add

  // Stats changes
  std::map<std::string, Statistics> added_stats_;  // New stats to add (key -> Statistics)

  // Index changes
  std::vector<Index> added_indexes_;      // Indexes to add or replace
  std::vector<int64_t> dropped_indexes_;  // index_id to drop

  // LOB file changes
  std::vector<LobFileInfo> added_lob_files_;  // New LOB files to add
};

/**
 * @brief Resolver interface for conflict resolution between read and latest manifests.
 *
 * A Resolver implementation reconciles the manifest read when a transaction began
 * with the most recent committed manifest, producing the manifest that will be
 * written by the commit.
 *
 * Resolver instances are expected to be stateless and shared (typically static
 * globals). The caller must keep the Resolver alive for the lifetime of any
 * Transaction that references it.
 */
class Resolver {
  public:
  virtual ~Resolver() = default;

  /**
   * @brief Resolve a commit.
   *
   * @param read_manifest The manifest read when the transaction began
   * @param read_version The version of the read manifest
   * @param latest_manifest The most recent committed manifest at conflict-resolution time
   *        (may be null if the implementation reported requireLatest() == false and the
   *        commit detected version drift; never null when read_version == latest_version
   *        or when requireLatest() == true)
   * @param latest_version The version of the latest manifest
   * @param updates The recorded changes in this transaction
   * @return Resolved manifest or error status
   */
  [[nodiscard]] virtual arrow::Result<std::shared_ptr<Manifest>> resolve(
      const std::shared_ptr<Manifest>& read_manifest,
      int64_t read_version,
      const std::shared_ptr<Manifest>& latest_manifest,
      int64_t latest_version,
      const Updates& updates) const = 0;

  /**
   * @brief Whether this resolver needs the latest manifest contents loaded.
   *
   * When false, the transaction commit logic will skip reading manifest-N.avro
   * from storage on version drift and pass a null latest_manifest to resolve().
   * Implementations that ignore latest_manifest (or only use it when versions
   * match, in which case the read is unnecessary) should return false to avoid
   * spurious commit failures from transient read errors on an otherwise-unused
   * manifest file.
   */
  [[nodiscard]] virtual bool requireLatest() const = 0;
};

// ==================== Helper Functions ====================

/**
 * @brief Apply updates to a manifest
 *
 * Creates a copy of the manifest and applies all updates (appended files, added column groups,
 * delta logs, stats) to it.
 *
 * @param manifest Base manifest to apply updates to
 * @param updates Updates to apply
 * @return New manifest with updates applied, or error status
 */
arrow::Result<std::shared_ptr<Manifest>> applyUpdates(const std::shared_ptr<Manifest>& manifest,
                                                      const Updates& updates);

// ==================== Helper Resolver Functions ====================

/**
 * @brief Resolver that applies updates to read_manifest, overwriting any concurrent changes
 *
 * This resolver applies all changes (appended files, added column groups, delta logs, stats)
 * into the read_manifest, ignoring any concurrent changes in latest_manifest.
 * requireLatest() == false — the commit logic skips reading manifest-N.avro on version drift.
 */
extern const Resolver& OverwriteResolver;

/**
 * @brief Resolver that fails if latest version differs from read version
 *
 * When read_version equals latest_version, applies updates to latest_manifest (or
 * read_manifest if latest_manifest is null). When versions differ, returns a
 * TxnResolutionFailed error without touching latest_manifest.
 *
 * requireLatest() == false: it is safe for Commit() to skip reading manifest-N.avro on
 * version drift, since the resolver only inspects manifests when versions match.
 */
extern const Resolver& FailResolver;

class Transaction {
  public:
  // Static factory method to open a transaction
  // @param fs Filesystem to use
  // @param base_path Base path for the storage
  // @param version Version to read from (default: LATEST = fetch greatest version)
  // @param resolver Resolver for conflict resolution (default: FailResolver). The
  //        Transaction stores a non-owning pointer to this object; the caller MUST keep
  //        the resolver alive for the lifetime of the returned Transaction. Do not pass
  //        a temporary.
  // @param retry_limit Maximum number of retry attempts on commit conflicts (default: 1)
  static arrow::Result<std::unique_ptr<Transaction>> Open(const milvus_storage::ArrowFileSystemPtr& fs,
                                                          const std::string& base_path,
                                                          int64_t version = LATEST,
                                                          const Resolver& resolver = FailResolver,
                                                          uint32_t retry_limit = 1);

  ~Transaction() = default;

  // Commit using Updates (uses the resolver set via Open)
  // Returns the committed version number on success
  arrow::Result<int64_t> Commit();

  // Get manifest on read version
  // Returns empty manifest if read_version_ is 0 (no manifest exists)
  arrow::Result<std::shared_ptr<Manifest>> GetManifest();

  // Get the read version of this transaction
  [[nodiscard]] int64_t GetReadVersion() const;

  // ==================== Fluent-style Builder Methods ====================

  /**
   * @brief Drop a single column from the manifest
   *
   * Removes the column from its column group. If the column group becomes
   * empty after removal, the entire column group is removed.
   * Automatically drops all indexes on this column.
   * Noop if the column doesn't exist (consistent with DropIndex).
   *
   * @param column_name Name of the column to drop
   * @return Reference to this transaction for method chaining
   */
  Transaction& DropColumn(const std::string& column_name);

  /**
   * @brief Add a new column group to the transaction updates
   * @param cg Column group to add
   * @return Reference to this transaction for method chaining
   */
  Transaction& AddColumnGroup(const std::shared_ptr<ColumnGroup>& cg);

  /**
   * @brief Append files to existing column groups
   * @param cgs Column groups containing files to append
   * @return Reference to this transaction for method chaining
   */
  Transaction& AppendFiles(const std::vector<std::shared_ptr<ColumnGroup>>& cgs);

  /**
   * @brief Add a delta log to the transaction updates
   * @param delta_log Delta log to add
   * @return Reference to this transaction for method chaining
   */
  Transaction& AddDeltaLog(const DeltaLog& delta_log);

  /**
   * @brief Add a stat entry to the transaction updates
   * @param key Stat key (e.g., "pk.delete", "bloomfilter", "bm25")
   * @param stat Statistics containing file paths and optional metadata
   * @return Reference to this transaction for method chaining
   */
  Transaction& UpdateStat(const std::string& key, const Statistics& stat);

  /**
   * @brief Record or replace metadata for an already-written index file.
   *
   * This method only records Index metadata. It does not perform index-file
   * I/O or return a file handle.
   */
  Transaction& AddIndexInfo(const Index& index);

  /**
   * @brief Drop all completed artifacts for an index.
   * @return Reference to this transaction for method chaining
   */
  Transaction& DropIndex(int64_t index_id);

  /**
   * @brief Add a LOB file to the transaction updates
   * @param lob_file LOB file info to add
   * @return Reference to this transaction for method chaining
   */
  Transaction& AddLobFile(const LobFileInfo& lob_file);

  private:
  // Private constructor - use Open() factory method instead
  Transaction(const milvus_storage::ArrowFileSystemPtr& fs,
              const std::string& base_path,
              int64_t read_version,
              const Resolver& resolver,
              uint32_t retry_limit);

  // Get latest version from filesystem
  arrow::Result<int64_t> get_latest_version();

  // Read manifest from filesystem at given version
  arrow::Result<std::shared_ptr<Manifest>> read_manifest(int64_t version);

  arrow::Status write_manifest(const std::shared_ptr<Manifest>& manifest, int64_t old_version, int64_t new_version);

  int64_t read_version_;
  std::shared_ptr<Manifest> read_manifest_;
  std::string base_path_;
  Updates updates_;           ///< Transaction updates tracked for resolver
  const Resolver* resolver_;  ///< Non-owning pointer to the resolver supplied at Open()
  milvus_storage::ArrowFileSystemPtr fs_;
  uint32_t retry_limit_;  ///< Maximum number of retry attempts on commit conflicts
};

}  // namespace milvus_storage::api::transaction
