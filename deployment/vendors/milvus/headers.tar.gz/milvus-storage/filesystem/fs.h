// Copyright 2024 Zilliz
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <memory>
#include <string>
#include <mutex>
#include <map>
#include <optional>
#include <shared_mutex>
#include <unordered_map>
#include <list>
#include <vector>

#include <arrow/filesystem/filesystem.h>
#include <arrow/util/uri.h>
#include <arrow/result.h>
#include <fmt/format.h>

#include "milvus-storage/common/config.h"
#include "milvus-storage/common/fiu_local.h"
#include "milvus-storage/common/lrucache.h"
#include "milvus-storage/filesystem/observable.h"
#include "milvus-storage/filesystem/upload_conditional.h"
#include "milvus-storage/filesystem/upload_sizable.h"
#include "milvus-storage/properties.h"

namespace milvus_storage {

inline constexpr const char* kCloudProviderAWS = "aws";
inline constexpr const char* kCloudProviderGCP = "gcp";
inline constexpr const char* kCloudProviderAliyun = "aliyun";
inline constexpr const char* kCloudProviderTencent = "tencent";
inline constexpr const char* kCloudProviderHuawei = "huawei";
inline constexpr const char* kCloudProviderAzure = "azure";

inline constexpr const char* kAzureFileSystemName = "abfs";

using ArrowFileSystemPtr = std::shared_ptr<arrow::fs::FileSystem>;

class FileSystemProxy : public arrow::fs::SubTreeFileSystem,
                        public UploadConditional,
                        public Observable,
                        public UploadSizable {
  public:
  FileSystemProxy(const std::string& base_path, std::shared_ptr<arrow::fs::FileSystem> base_fs)
      : arrow::fs::SubTreeFileSystem(base_path, std::move(base_fs)) {}

  std::string type_name() const override { return base_fs()->type_name(); }

  // Override OpenOutputStream to add fault injection point
  arrow::Result<std::shared_ptr<arrow::io::OutputStream>> OpenOutputStream(
      const std::string& path, const std::shared_ptr<const arrow::KeyValueMetadata>& metadata) override {
    FIU_RETURN_ON(FIUKEY_FS_OPEN_OUTPUT_FAIL,
                  arrow::Status::IOError(fmt::format("Injected fault: {}", FIUKEY_FS_OPEN_OUTPUT_FAIL)));
    return SubTreeFileSystem::OpenOutputStream(path, metadata);
  }

  // Override OpenInputFile to add fault injection point
  arrow::Result<std::shared_ptr<arrow::io::RandomAccessFile>> OpenInputFile(const std::string& path) override {
    FIU_RETURN_ON(FIUKEY_FS_OPEN_INPUT_FAIL,
                  arrow::Status::IOError(fmt::format("Injected fault: {}", FIUKEY_FS_OPEN_INPUT_FAIL)));
    return SubTreeFileSystem::OpenInputFile(path);
  }

  arrow::Result<std::shared_ptr<arrow::io::OutputStream>> OpenConditionalOutputStream(
      const std::string& path, std::shared_ptr<arrow::KeyValueMetadata> metadata) override {
    FIU_RETURN_ON(FIUKEY_FS_OPEN_OUTPUT_FAIL,
                  arrow::Status::IOError(fmt::format("Injected fault: {}", FIUKEY_FS_OPEN_OUTPUT_FAIL)));
    auto conditional = std::dynamic_pointer_cast<UploadConditional>(base_fs());
    if (!conditional) {
      return arrow::Status::NotImplemented("Filesystem does not implement UploadConditional");
    }

    ARROW_ASSIGN_OR_RAISE(auto full_path, PrependBase(path));
    return conditional->OpenConditionalOutputStream(full_path, std::move(metadata));
  }

  std::shared_ptr<FilesystemMetrics> GetMetrics() const override {
    auto observable = std::dynamic_pointer_cast<Observable>(base_fs());
    if (!observable) {
      return nullptr;
    }
    return observable->GetMetrics();
  }

  arrow::Result<std::shared_ptr<arrow::io::OutputStream>> OpenOutputStreamWithUploadSize(
      const std::string& path,
      const std::shared_ptr<const arrow::KeyValueMetadata>& metadata,
      int64_t part_size) override {
    auto sizable = std::dynamic_pointer_cast<UploadSizable>(base_fs());
    if (!sizable) {
      return arrow::Status::NotImplemented("Filesystem does not implement UploadSizable");
    }

    ARROW_ASSIGN_OR_RAISE(auto full_path, PrependBase(path));
    return sizable->OpenOutputStreamWithUploadSize(full_path, metadata, part_size);
  }
};

/**
 * Check current filesystem is local filesystem
 * If current filesystem is "SubTreeFileSystem", it will check the base filesystem
 */
bool IsLocalFileSystem(const ArrowFileSystemPtr& fs);

/**
 * @brief Parsed storage URI components
 *
 * A generic URI parser for cloud storage systems that supports:
 * - Absolute URIs: s3://[endpoint/]bucket/key
 * - Relative paths: path/to/file
 */
struct StorageUri {
  std::string scheme;       // URI scheme (e.g., "s3"), or "" for relative paths
  std::string address;      // Optional endpoint/host, or "" for relative paths
  std::string bucket_name;  // Bucket/container name, or "" for relative paths
  std::string key;          // Object key/path, or full path for relative paths

  [[nodiscard]] bool IsRelativeUri() const { return scheme.empty(); }
  [[nodiscard]] bool IsAbsoluteUri() const { return !scheme.empty(); }
  [[nodiscard]] const std::string& ToRelativePath() const { return key; }

  /**
   * @brief Parse a storage URI or relative path into components
   *
   * @param uri The URI string or relative path to parse
   * @param include_address If true (default), host is treated as endpoint/address
   *   and first path segment as bucket: s3://endpoint/bucket/key.
   *   If false, host is treated as bucket: s3://bucket/key.
   */
  static arrow::Result<StorageUri> Parse(const std::string& uri, bool include_address = true);

  /**
   * @brief Construct a URI string from components (inverse of Parse)
   *
   * @param include_address If true (default), produces scheme://address/bucket/key.
   *   If false, produces scheme://bucket/key (address is ignored).
   */
  static arrow::Result<std::string> Make(const StorageUri& uri, bool include_address = true);

  /// Ensure address has a URL scheme. If no scheme is present, uses use_ssl
  /// to choose "https://" or "http://".
  static std::string BuildEndpointUrl(const std::string& address, bool use_ssl = true);

  /// Build Azure endpoint URL from authority and account name.
  /// '.' prefix → virtual-hosted: https://account.blob.core.windows.net
  /// otherwise  → path-style:     http://127.0.0.1:10000/account
  static std::string BuildAzureEndpointAddress(const std::string& address,
                                               const std::string& account_name,
                                               bool use_ssl);
};

// TODO: it's not `arrow` namespace, we should change this struct name.
// TODO: after chunkmanager(in milvus) removed, we can remove the used key in storage
struct ArrowFileSystemConfig {
  std::string address = "";
  std::string bucket_name = "";
  std::string access_key_id = "";
  std::string access_key_value = "";

  // Only applies to the local filesystem.
  // It is used to pin the data directory to a specific path.
  // Supports absolute and relative paths, A relative path
  // is relative to the working directory of the current process.
  std::string root_path = "files";
  std::string storage_type = "local";
  std::string cloud_provider = kCloudProviderAWS;
  std::string iam_endpoint = "";   // Deprecated
  std::string log_level = "warn";  // only use on global config
  std::string region = "";
  bool use_ssl = false;
  std::string ssl_ca_cert = "";
  bool use_iam = false;
  bool use_virtual_host = false;
  int64_t request_timeout_ms = 3000;
  bool gcp_native_without_auth = false;  // Deprecated
  std::string gcp_credential_json = "";  // Deprecated
  bool use_custom_part_upload = true;    // Deprecated
  uint32_t max_connections = 100;

  // Work on S3FileSystem, not worked on azurefs
  // To align with the old logical, set to `int64_t`(should be `uint64_t`)
  int64_t multi_part_upload_size = DEFAULT_MULTIPART_UPLOAD_PART_SIZE;

  // AssumeRole credentials
  std::string role_arn = "";
  std::string session_name = "";
  std::string external_id = "";

  // GCP cross-tenant access (Service Account Impersonation)
  // Target service account email to impersonate (e.g., "sa@project.iam.gserviceaccount.com")
  std::string gcp_target_service_account = "";

  // Azure broker-backed temporary SAS authentication.
  std::string azure_client_id = "";
  std::string azure_tenant_id = "";
  std::string azure_credential_endpoint = "";

  // Lifetime requested for cross-tenant temporary credentials, in seconds.
  // Shared across providers that mint short-lived tokens:
  //   - AWS STS AssumeRole: STS session length (valid range [900, 43200],
  //     reachable only when the target role's MaxSessionDuration is raised
  //     from the 3600s default).
  //   - GCP IAM impersonated service account: lifetime passed to
  //     `iamcredentials.generateAccessToken`; rejected at provider-build time
  //     if outside [900, 3600] (the `iam.allowServiceAccountCredentialLifetimeExtension`
  //     org-policy escape hatch is not plumbed through).
  //   - Azure credential broker: requested SAS lifetime.
  // Long-lived readers refresh credentials ahead of expiry; one-shot readers
  // request credentials with this lifetime when they start.
  // Ignored by providers that don't mint temporary credentials (plain AKSK,
  // Azure account key, etc.).
  int32_t load_frequency = 900;

  // Minimum TLS version for HTTPS connections.
  // Supported values: "", "1.0", "1.1", "1.2", "1.3"
  // Empty string means use the system/library default.
  std::string tls_min_version = "";

  // Whether OutputStream writes will be issued in the background, without blocking.
  // Only applies to S3 filesystem. It will use the thread pool which in arrow.
  bool background_writes = true;

  // Whether to use CRC32C checksum for S3 uploads.
  // Only AWS S3 and MinIO support this; other providers (Huawei OBS, Aliyun OSS,
  // Tencent COS, GCS S3-compat) will silently ignore the checksum header.
  bool use_crc32c_checksum = false;

  // Whether S3 OpenInputFile should use the AWS CRT-backed async reader when
  // WITH_CRT is enabled. Ignored by non-S3 filesystems and non-CRT builds.
  bool s3_crt_async_read = true;

  // Shared Lance scheduler capacity for remote reader fragment I/O.
  // Zero preserves Lance's existing per-Dataset scheduler behavior.
  uint32_t lance_io_parallelism = 64;

  // ObjectStore request-rate settings. Currently only Lance supports them.
  uint32_t iops_initial_rate = 2000;
  uint32_t iops_max_rate = 5000;

  // Alias for external filesystem identification (e.g., "prod", "backup")
  // Empty for default filesystem
  std::string alias = "";

  static arrow::Status create_file_system_config(const milvus_storage::api::Properties& properties_map,
                                                 ArrowFileSystemConfig& result);

  /**
   * @brief Return whether Azure credential broker authentication was requested.
   *
   * For Azure, any broker-specific property enables this mode so incomplete
   * configurations are rejected during validation instead of silently falling
   * back to another Azure authentication mechanism.
   */
  [[nodiscard]] bool IsAzureCredentialBrokerEnabled() const;

  /**
   * @brief Get the cache key for this filesystem configuration
   *
   * The cache key includes filesystem location, client behavior, and credential
   * identity fields. This prevents sharing one cached filesystem across configs
   * that target the same bucket with different credentials (for example,
   * different role_arn values).
   */
  [[nodiscard]] std::string GetCacheKey() const;

  [[nodiscard]] std::string ToString() const;
};

arrow::Result<ArrowFileSystemPtr> CreateArrowFileSystem(const ArrowFileSystemConfig& config);

class FileSystemProducer {
  public:
  virtual ~FileSystemProducer() = default;

  virtual arrow::Result<ArrowFileSystemPtr> Make() = 0;
};

/**
 * @brief Unified filesystem cache and external filesystem registry
 *
 * This singleton manages both:
 * 1. LRU cache of filesystem instances (by address+bucket combination)
 * 2. External filesystem configurations from properties (extfs.* entries)
 *
 * Thread-safe for concurrent access.
 */
class FilesystemCache {
  public:
  static FilesystemCache& getInstance();

  /**
   * @brief Get or create a filesystem from properties and path
   *
   * This is the main API for obtaining filesystems. It automatically:
   * - Resolves external filesystems (extfs.*) if path has a scheme
   * - Falls back to default filesystem (fs.*) otherwise
   * - Caches all filesystems by address+bucket
   *
   * @param properties Properties containing filesystem configuration
   * @param path Optional path to determine filesystem (empty = default filesystem)
   * @return Result containing the cached or newly created filesystem
   */
  [[nodiscard]] arrow::Result<ArrowFileSystemPtr> get(const api::Properties& properties, const std::string& path = "");

  /**
   * @brief Resolve filesystem config from properties and URI path
   *
   * If path has a scheme, matches extfs.* config by address+bucket.
   * Otherwise returns default fs.* config.
   * Does NOT create a filesystem or touch the cache.
   */
  [[nodiscard]] static arrow::Result<ArrowFileSystemConfig> resolve_config(const api::Properties& properties,
                                                                           const std::string& path = "");

  /**
   * @brief Get the size of cached filesystems
   */
  [[nodiscard]] size_t size() const;

  /**
   * @brief List all cached filesystems without changing their recency
   *
   * Each returned pair is `{display_key, filesystem}`. See MakeDisplayKey()
   * for the display key composition. The display key is not the internal cache
   * key accepted by remove().
   */
  [[nodiscard]] std::vector<std::pair<std::string, ArrowFileSystemPtr>> list() const;

  /**
   * @brief Remove a cached filesystem by key
   */
  void remove(const std::string& key);

  /**
   * @brief Clear all cached filesystems and external filesystem registrations
   */
  void clean();

  /**
   * @brief Set the cache capacity
   */
  void set_capacity(size_t capacity);

  public:
  FilesystemCache(const FilesystemCache&) = delete;
  FilesystemCache& operator=(const FilesystemCache&) = delete;

  private:
  struct CacheEntry {
    std::string display_key;
    ArrowFileSystemPtr filesystem;
  };

  /**
   * @brief Build a display key from the filesystem location and its internal cache key
   *
   * Local format: `file://{root_path}#{cache_key}`.
   * Remote format: `{address}/{bucket_name}#{cache_key}`. An empty remote
   * address is rendered as `<null>`. `cache_key` is the existing internal LRU
   * key returned by ArrowFileSystemConfig::GetCacheKey().
   */
  [[nodiscard]] static std::string MakeDisplayKey(const ArrowFileSystemConfig& config, const std::string& cache_key);

  explicit FilesystemCache(size_t capacity) : cache_(capacity) {}
  ~FilesystemCache() = default;

  // Filesystem instance cache (LRU)
  mutable std::mutex mutex_;
  LRUCache<std::string, std::shared_ptr<CacheEntry>> cache_;
};

}  // namespace milvus_storage
