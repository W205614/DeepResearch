-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: tar
Binary: tar, tar-scripts
Architecture: any
Version: 1.34+dfsg-1ubuntu0.1.22.04.6
Maintainer: Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>
Uploaders: Carl Worth <cworth@cworth.org>
Homepage: https://www.gnu.org/software/tar/
Standards-Version: 4.3.0
Vcs-Browser: https://salsa.debian.org/debian/tar
Vcs-Git: https://salsa.debian.org/debian/tar.git
Build-Depends: debhelper (>> 10), gettext, autoconf, automake, autopoint, bison, libacl1-dev, libselinux1-dev [linux-any]
Package-List:
 tar deb utils required arch=any essential=yes
 tar-scripts deb utils optional arch=any
Checksums-Sha1:
 4f37d162cb262830092ae25aab61abb08785181c 1981736 tar_1.34+dfsg.orig.tar.xz
 efbaaa6a16d8377287a00d5a06948c33005e3dc4 56112 tar_1.34+dfsg-1ubuntu0.1.22.04.6.debian.tar.xz
Checksums-Sha256:
 7d57029540cb928394defb3b377b3531237c947e795b51aa8acac0c5ba0e4844 1981736 tar_1.34+dfsg.orig.tar.xz
 703c426985c42f7f4c7f9714a6ff9167437ed1bdb35e07235f591c565d670e24 56112 tar_1.34+dfsg-1ubuntu0.1.22.04.6.debian.tar.xz
Files:
 a5777dd3e21dd72bb44244845f0b6fcb 1981736 tar_1.34+dfsg.orig.tar.xz
 47f24241b94d4c0dbbbae62269c15d94 56112 tar_1.34+dfsg-1ubuntu0.1.22.04.6.debian.tar.xz
Original-Maintainer: Janos Lenart <ocsi@debian.org>

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEf+ebRFcoyOoAQoOeRbznW4QLH2kFAmpeSVsACgkQRbznW4QL
H2kUAA//c5Xmo/Rfic3kE7r4hph0Vi8jzqDEVltl1r0zviBkCZ48T4Ho0UQuOJKM
wU7jae3h3w/1FeAayu+5L1Dzpm8sDcMYEOTctdU43D1Krv7uyVLYgLLXluS8AO90
hzXXNPuDO+6XjoyEwfekARn3xt3lCdt/XvO1sHI/PC3M5WY8eg2wjWuhC3Mo+EIE
0euq8a5XCq/pCGja6MR0xVn62ALry/TEPneEoufH23LKv03dgUVWb368xao6RN9s
mWbwi/A2OYVKaUkrFb/2a0tnzAWGLti4a84iEXZUr5OIbI3MefchGMG7SXZxBsAc
KjVm8eVNwQ7/IadS48pUnB7D/mnANkOgGpwbTia29S8lHfn6BGCF7VLeWaD+azae
H1GaDbXaWMh1Rvn7gaay9nZvMyYrlvSyEzu2qy7DF8lJyR4F74wYNQoopz5uD+di
VMlhdj8Lo8uzQABGi1tnqjddwxXtyp6seGj01uhUSE3RQR4wM7mtDDClEvVyTHnE
FrUdxG1fSPlm0jbiNl5ejxfIv/0CMuMi8PQVacf4FQXLPxyjnCpc2kJ0HGtPlH6N
QjNaMcU1E/qzAq4Je7rcC/jYK0mpUkc/xa2hwU80F54AuOtFkGgYIqnHbKCCyHlA
TMQRFQ85TQD8qhsHsPeXK0RpV08ngMrDfyNZG8G+EJ8fvkxIOzk=
=MGkU
-----END PGP SIGNATURE-----
