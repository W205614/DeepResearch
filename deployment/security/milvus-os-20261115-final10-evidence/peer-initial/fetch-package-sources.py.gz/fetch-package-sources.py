from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re

import httpx

OUT = Path(__file__).resolve().parent
items = []
for family, path in [('dash', 'd/dash'), ('ncurses', 'n/ncurses'), ('tar', 't/tar')]:
    raw = (OUT / (family + '-source.dsc')).read_text()
    section = raw.split('Checksums-Sha256:\n', 1)[1].split('\nFiles:', 1)[0]
    for line in section.splitlines():
        match = re.fullmatch(r' ([0-9a-f]{64}) (\d+) (\S+)', line)
        if match:
            digest, size, name = match.groups()
            items.append({'family': family, 'file': name, 'sha256': digest, 'bytes': int(size),
                          'url': 'https://archive.ubuntu.com/ubuntu/pool/main/' + path + '/' + name})


def fetch(row):
    try:
        response = httpx.get(row['url'], timeout=60)
        response.raise_for_status()
        body = response.content
        assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        (OUT / row['file']).write_bytes(body)
        return {**row, 'official_archive_https_and_dsc_sha256_match': True, 'dsc_signature_verified': False}
    except Exception as error:
        return {**row, 'error_type': type(error).__name__}


with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(fetch, items))
(OUT / 'ubuntu-package-source-receipts.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results))
