package main

import (
 "bytes"
 "debug/elf"
 "encoding/json"
 "os"
 "sort"
)

func main() {
 result := map[string]interface{}{}
 for _, name := range os.Args[1:] {
  f, err := elf.Open(name); if err != nil { panic(err) }
  syms, err := f.DynamicSymbols(); if err != nil { panic(err) }
  imported, defined := []string{}, []string{}
  for _, sym := range syms { if sym.Section == elf.SHN_UNDEF { imported = append(imported, sym.Name) } else { defined = append(defined, sym.Name) } }
  sort.Strings(imported); sort.Strings(defined)
  libs, err := f.ImportedLibraries(); if err != nil { panic(err) }
  body, err := os.ReadFile(name); if err != nil { panic(err) }
  markers := map[string]bool{}
  for _, m := range []string{"DIGEST-MD5", "add_to_challenge", "_nc_wrap_entry", "rust_demangle", "demangle_const", "UTIL_getFileSize", "fnmatch"} { markers[m] = bytes.Contains(body, []byte(m)) }
  result[name] = map[string]interface{}{"DT_NEEDED": libs, "undefined_dynamic_symbols": imported, "defined_dynamic_symbols": defined, "exact_ascii_markers": markers}
  f.Close()
 }
 if err := json.NewEncoder(os.Stdout).Encode(result); err != nil { panic(err) }
}
