from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
packages = json.loads((OUT / 'actual-unfixed-package-files.json').read_bytes())
selected = ('usr/bin/dash', 'usr/bin/tic', 'usr/lib/x86_64-linux-gnu/libtinfo.so.6.3',
            'usr/lib/x86_64-linux-gnu/libtic.so.6.3',
            'usr/lib/x86_64-linux-gnu/libncurses.so.6.3', 'usr/lib/x86_64-linux-gnu/libncursesw.so.6.3',
            'usr/lib/x86_64-linux-gnu/libsasl2.so.2.0.25', 'usr/lib/x86_64-linux-gnu/libstdc++.so.6.0.30',
            'usr/lib/x86_64-linux-gnu/libgcc_s.so.1', 'usr/lib/x86_64-linux-gnu/libgomp.so.1.0.0')
with tarfile.open(OUT.parent / 'milvus-runtime-01/actual-payload/rootfs.tar') as archive:
    entries = {m.name.removeprefix('./').rstrip('/'): m for m in archive}
    files = {}
    for name in selected:
        if name not in entries:
            continue
        raw = archive.extractfile(entries[name]).read()
        path = OUT / (name.replace('/', '_') + '.elf')
        path.write_bytes(raw)
        files[name] = {'extracted_file': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
environment = {**os.environ, 'GOTOOLCHAIN': 'local', 'GO111MODULE': 'off'}
command = ['go', 'run', str(OUT / 'elf-facts.go'), *[r['extracted_file'] for r in files.values()]]
raw = subprocess.check_output(command, env=environment)
(OUT / 'actual-elf-dynamic-facts.json').write_bytes(raw)
facts = json.loads(raw)
for name, row in files.items():
    row['elf'] = facts[row['extracted_file']]
(OUT / 'actual-elf-evidence.json').write_text(json.dumps(files, indent=2) + '\n', encoding='utf-8')
print(json.dumps({name: {'libraries': row['elf']['DT_NEEDED'],
                        'markers': row['elf']['exact_ascii_markers']} for name, row in files.items()}, indent=2))
