-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: ncurses
Binary: ncurses-base, ncurses-term, libtinfo6, libtinfo6-udeb, libncurses6, libncurses-dev, libtinfo-dev, libncurses5-dev, libncursesw6, libncursesw6-udeb, libncursesw5-dev, lib64tinfo6, lib64ncurses6, lib64ncursesw6, lib64ncurses-dev, lib32tinfo6, lib32ncurses6, lib32ncursesw6, lib32ncurses-dev, ncurses-bin, ncurses-examples, ncurses-doc, libtinfo5, libncurses5, libncursesw5
Architecture: any all
Version: 6.3-2ubuntu0.3
Maintainer: Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>
Uploaders: Sven Joachim <svenjoac@gmx.de>
Homepage: https://invisible-island.net/ncurses/
Standards-Version: 4.5.1
Vcs-Browser: https://salsa.debian.org/debian/ncurses
Vcs-Git: https://salsa.debian.org/debian/ncurses.git
Build-Depends: debhelper-compat (= 13), libgpm-dev [linux-any], pkg-config, libmd-dev [kfreebsd-any], autoconf-dickey (>= 2.52+20210509)
Build-Depends-Arch: g++-multilib [amd64 i386 powerpc ppc64 s390 sparc] <!nobiarch>
Package-List:
 lib32ncurses-dev deb libdevel optional arch=amd64,ppc64 profile=!nobiarch
 lib32ncurses6 deb libs optional arch=amd64,ppc64 profile=!nobiarch
 lib32ncursesw6 deb libs optional arch=amd64,ppc64 profile=!nobiarch
 lib32tinfo6 deb libs optional arch=amd64,ppc64 profile=!nobiarch
 lib64ncurses-dev deb libdevel optional arch=i386,powerpc,sparc,s390 profile=!nobiarch
 lib64ncurses6 deb libs optional arch=i386,powerpc,sparc,s390 profile=!nobiarch
 lib64ncursesw6 deb libs optional arch=i386,powerpc,sparc,s390 profile=!nobiarch
 lib64tinfo6 deb libs optional arch=i386,powerpc,sparc,s390 profile=!nobiarch
 libncurses-dev deb libdevel optional arch=any
 libncurses5 deb oldlibs optional arch=any profile=!pkg.ncurses.nolegacy
 libncurses5-dev deb oldlibs optional arch=any
 libncurses6 deb libs optional arch=any
 libncursesw5 deb oldlibs optional arch=any profile=!pkg.ncurses.nolegacy
 libncursesw5-dev deb oldlibs optional arch=any
 libncursesw6 deb libs optional arch=any
 libncursesw6-udeb udeb debian-installer optional arch=any profile=!noudeb
 libtinfo-dev deb oldlibs optional arch=any
 libtinfo5 deb oldlibs optional arch=any profile=!pkg.ncurses.nolegacy
 libtinfo6 deb libs optional arch=any
 libtinfo6-udeb udeb debian-installer optional arch=any profile=!noudeb
 ncurses-base deb misc required arch=all essential=yes
 ncurses-bin deb utils required arch=any essential=yes
 ncurses-doc deb doc optional arch=all
 ncurses-examples deb misc optional arch=any profile=!pkg.ncurses.noexamples
 ncurses-term deb misc standard arch=all
Checksums-Sha1:
 38fb1462d13b04bb900adf07918725c4b7ed0682 3583550 ncurses_6.3.orig.tar.gz
 6c5fccc716dbf84b6d60e7fb0df45aef9d90f67e 729 ncurses_6.3.orig.tar.gz.asc
 ffce4f054a2ce82a04fa3ce74e1910a6a3023328 57172 ncurses_6.3-2ubuntu0.3.debian.tar.xz
Checksums-Sha256:
 97fc51ac2b085d4cde31ef4d2c3122c21abc217e9090a43a30fc5ec21684e059 3583550 ncurses_6.3.orig.tar.gz
 37b9e80c11fa02fbd8caf42ab9573427f54f2c7212eb4aeec9f455b5d79dee14 729 ncurses_6.3.orig.tar.gz.asc
 05dbb05d1001c90b8cd30f608f3efd15a77a14ca675ef9e23041d6ebc26c1942 57172 ncurses_6.3-2ubuntu0.3.debian.tar.xz
Files:
 a2736befde5fee7d2b7eb45eb281cdbe 3583550 ncurses_6.3.orig.tar.gz
 7410b0bb10e5a381a3e18afe82ff0168 729 ncurses_6.3.orig.tar.gz.asc
 807431266ee47b4b6cc5de034628b604 57172 ncurses_6.3-2ubuntu0.3.debian.tar.xz
Original-Maintainer: Craig Small <csmall@debian.org>

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEyMDHOTG0YH5UsajI8pSCVQZYHygFAmqVa1EACgkQ8pSCVQZY
Hyg1xg//Xbs1I7xsvDbbIK8ePbITeR96OcZSZDOevUf8jRelSW0Ww9kNOpx+BwB+
hdqz40db2eFQrFxiNZWmoBw+sWTrYwqRJuT3zkSwaJkcW2HMWaXEYh8VG7BKtguW
pLsqOYLKpGa1KYCgzPpaf2ne35yhjKJJQ8Cym0IIWn3Ti/qwO/bTOx9foa8HCOtW
h9wsCa94qVQjlE7j59UfYSx/vWzWDE6QyTE/g18rOicMqPGX67NHCQ0t2z2eQ2dE
FQ4fTRC/zoC9Eu+Vvd3izNOZMnnqxd9ywIJ3CnAtFsSzZr/EbeJ0vmSIPBlAyUe2
DrofqtbrekePwuOVRxWJKeB1T+UkctZSnr8yz4WSynIMo+EGOIr647TCj66dkhIb
ieEifevekO1n0clkgCu3SJSrAWi0n+vp8BfY7MGFY+i62h9H7/+jGZMBE6K5aGLB
nF+1uFp3cgmVoKVtYo72d4jM+BXyl4a6HlNrE9aNbSsUOjn+PJptqUeiNeIpGEVJ
hUipSXCbvF+vQVeeW/Cs90EQeQjb8XpEDuiTynebSf9V5OELqRaKEo9bn764GZSD
MZM2sYXUzMN33f72e05VQGCTpLRr19vlObdKnM49ypc0BK+Bvh9cxau55WPFP0XB
xsKdiyGep4J+AQKIkinymj3L8Vnxet068d1SeEBBlgKSLsNGEpY=
=ujjN
-----END PGP SIGNATURE-----
