package main

import (
 "archive/tar"
 "bytes"
 "crypto/sha256"
 "debug/elf"
 "encoding/hex"
 "encoding/json"
 "io"
 "os"
 "strings"
)

func main() {
 input, err := os.Open(os.Args[1]); if err != nil { panic(err) }; defer input.Close()
 archive := tar.NewReader(input)
 files, links := map[string]interface{}{}, map[string]interface{}{}
 for {
  header, err := archive.Next(); if err == io.EOF { break }; if err != nil { panic(err) }
  name := strings.TrimPrefix(header.Name, "./")
  if header.Typeflag == tar.TypeSymlink || header.Typeflag == tar.TypeLink { links[name] = map[string]interface{}{"type": string(header.Typeflag), "target": header.Linkname}; continue }
  if header.Typeflag != tar.TypeReg && header.Typeflag != tar.TypeRegA { continue }
  magic := make([]byte, 4); n, err := io.ReadFull(archive, magic); if err == io.EOF || err == io.ErrUnexpectedEOF { continue }; if err != nil { panic(err) }
  if n != 4 || !bytes.Equal(magic, []byte{0x7f,'E','L','F'}) { continue }
  rest, err := io.ReadAll(archive); if err != nil { panic(err) }; body := append(magic, rest...)
  f, err := elf.NewFile(bytes.NewReader(body)); if err != nil { panic(err) }
  needed, err := f.ImportedLibraries(); if err != nil { panic(err) }
  digest := sha256.Sum256(body)
  files[name] = map[string]interface{}{"sha256": hex.EncodeToString(digest[:]), "bytes": len(body), "mode": header.Mode,
    "DT_NEEDED": needed, "contains_DIGEST_MD5_mechanism_name": bytes.Contains(body, []byte("DIGEST-MD5")),
    "contains_nc_compiler_entry_name": bytes.Contains(body, []byte("_nc_read_entry_source")),
    "contains_rust_demangle_name": bytes.Contains(body, []byte("rust_demangle"))}
  f.Close()
 }
 if err := json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"all_regular_elf": files,"all_symlinks_and_hardlinks": links,"elf_count": len(files)}); err != nil { panic(err) }
}
