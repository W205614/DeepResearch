from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path

import httpx

OUT = Path(__file__).resolve().parent
SOURCES = {
 'cyrus-digestmd5-pr892.patch': 'https://github.com/cyrusimap/cyrus-sasl/pull/892.patch',
 'cyrus-modules-filelist.html': 'https://packages.ubuntu.com/jammy-updates/amd64/libsasl2-modules/filelist',
 'cyrus-core-filelist.html': 'https://packages.ubuntu.com/jammy-updates/amd64/libsasl2-2/filelist',
 'shadow-chfn-fix.patch': 'https://github.com/shadow-maint/shadow/commit/e5905c4b84d4fb90aefcd96ee618411ebfac663d.patch',
 'pcre2-test-fix.patch': 'https://github.com/PCRE2Project/pcre2/commit/94e1c001761373b7d9450768aa15d04c25547a35.patch',
 'perl-globmapper-fix.patch': 'https://github.com/pmqs/IO-Compress/commit/f2db247bf90d4cc7ee2710be384946081f3b4610.patch',
 'gnutls-3.7.3-global.c': 'https://raw.githubusercontent.com/gnutls/gnutls/3.7.3/lib/global.c',
 'gnutls-3.7.3-verify.c': 'https://raw.githubusercontent.com/gnutls/gnutls/3.7.3/lib/x509/verify.c',
 'gnutls-3.7.3-hostname.c': 'https://raw.githubusercontent.com/gnutls/gnutls/3.7.3/lib/x509/hostname-verify.c',
 'gnutls-3.7.3-name-constraints.c': 'https://raw.githubusercontent.com/gnutls/gnutls/3.7.3/lib/x509/name_constraints.c',
 'ncurses-6.3.tar.gz': 'https://invisible-island.net/archives/ncurses/ncurses-6.3.tar.gz',
 'dash-source.dsc': 'https://archive.ubuntu.com/ubuntu/pool/main/d/dash/dash_0.5.11+git20210903+057cd650a4ed-3build1.dsc',
 'ncurses-source.dsc': 'https://archive.ubuntu.com/ubuntu/pool/main/n/ncurses/ncurses_6.3-2ubuntu0.3.dsc',
}


def get(item):
    name, url = item
    try:
        response = httpx.get(url, timeout=60, follow_redirects=True)
        response.raise_for_status()
        body = response.content
        assert body and len(body) < 20 * 1024 * 1024
        (OUT / name).write_bytes(body)
        return {'file': name, 'url': url, 'http_status': response.status_code,
                'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
    except Exception as error:
        return {'file': name, 'url': url, 'error_type': type(error).__name__}


with ThreadPoolExecutor(max_workers=4) as pool:
    result = list(pool.map(get, SOURCES.items()))
(OUT / 'upstream-source-receipts.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
