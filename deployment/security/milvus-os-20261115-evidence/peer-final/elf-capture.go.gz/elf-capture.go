package main

import (
 "archive/tar"
 "bytes"
 "crypto/sha256"
 "debug/elf"
 "encoding/hex"
 "encoding/json"
 "errors"
 "io"
 "os"
 "sort"
 "strings"
)

func main() {
 input, err := os.Open(os.Args[1]); if err != nil { panic(err) }; defer input.Close()
 archive := tar.NewReader(input)
 files, links := map[string]interface{}{}, map[string]interface{}{}
 for {
  header, err := archive.Next(); if err == io.EOF { break }; if err != nil { panic(err) }
  name := strings.TrimPrefix(header.Name, "./")
  if header.Typeflag == tar.TypeSymlink || header.Typeflag == tar.TypeLink { links[name] = map[string]interface{}{"type": string(header.Typeflag), "target": header.Linkname}; continue }
  if header.Typeflag != tar.TypeReg && header.Typeflag != tar.TypeRegA { continue }
  magic := make([]byte, 4); n, err := io.ReadFull(archive, magic); if err == io.EOF || err == io.ErrUnexpectedEOF { continue }; if err != nil { panic(err) }
  if n != 4 || !bytes.Equal(magic, []byte{0x7f,'E','L','F'}) { continue }
  rest, err := io.ReadAll(archive); if err != nil { panic(err) }; body := append(magic, rest...)
  f, err := elf.NewFile(bytes.NewReader(body)); if err != nil { panic(err) }
  needed, err := f.ImportedLibraries(); if err != nil { panic(err) }
  symbols, err := f.DynamicSymbols(); if err != nil && !errors.Is(err, elf.ErrNoSymbols) { panic(err) }
  public, gnutls := map[string]interface{}{}, []string{}
  sasl := []string{}
  for _, symbol := range symbols {
   if strings.HasPrefix(symbol.Name, "rd_kafka_") && symbol.Section != elf.SHN_UNDEF {
    public[symbol.Name] = map[string]interface{}{"type": elf.ST_TYPE(symbol.Info).String(), "binding": elf.ST_BIND(symbol.Info).String(), "visibility": symbol.Other & 3}
   }
   if strings.HasPrefix(symbol.Name, "gnutls_") && symbol.Section == elf.SHN_UNDEF { gnutls = append(gnutls, symbol.Name) }
   if strings.HasPrefix(symbol.Name, "sasl_") && symbol.Section == elf.SHN_UNDEF { sasl = append(sasl, symbol.Name) }
  }
  sort.Strings(gnutls); sort.Strings(sasl)
  soname, err := f.DynString(elf.DT_SONAME); if err != nil { panic(err) }
  digest := sha256.Sum256(body)
  files[name] = map[string]interface{}{"sha256": hex.EncodeToString(digest[:]), "bytes": len(body), "mode": header.Mode,
    "DT_NEEDED": needed, "SONAME": soname, "rd_kafka_public_definitions": public,
    "undefined_gnutls_symbols": gnutls, "undefined_sasl_symbols": sasl,
    "cyrus_digest_plugin_init": bytes.Contains(body, []byte("digestmd5_client_plug_init")) || bytes.Contains(body, []byte("digestmd5_server_plug_init")),
    "cyrus_add_to_challenge": bytes.Contains(body, []byte("add_to_challenge")),
    "cyrus_digest_source_error": bytes.Contains(body, []byte("Out of Memory in digestmd5.c")),
    "nc_compiler_entry": bytes.Contains(body, []byte("_nc_read_entry_source")),
    "rust_demangle": bytes.Contains(body, []byte("rust_demangle")),
    "gnutls_global_init_name": bytes.Contains(body, []byte("gnutls_global_init")),
    "gnutls_certificate_verify_name": bytes.Contains(body, []byte("gnutls_x509_crt_verify"))}
  f.Close()
 }
 if err := json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"all_regular_elf": files,"all_symlinks_and_hardlinks": links,"elf_count": len(files)}); err != nil { panic(err) }
}
